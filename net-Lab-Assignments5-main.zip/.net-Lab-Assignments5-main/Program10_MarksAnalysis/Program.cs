using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Program10_MarksAnalysis
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = "marks.txt";

            try
            {
                if (!File.Exists(filePath))
                {
                    throw new FileNotFoundException("File marks.txt was not found.", filePath);
                }

                string[] lines = File.ReadAllLines(filePath);
                List<double> marks = new List<double>();

                foreach (string line in lines)
                {
                    if (double.TryParse(line, out double mark))
                    {
                        marks.Add(mark);
                    }
                }

                if (marks.Count == 0)
                {
                    Console.WriteLine("No valid marks found in file.");
                    return;
                }

                Console.WriteLine($"Total: {marks.Sum()}");
                Console.WriteLine($"Average: {marks.Average()}");
                Console.WriteLine($"Highest: {marks.Max()}");
                Console.WriteLine($"Lowest: {marks.Min()}");
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine($"FileNotFoundException caught: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception caught: {ex.Message}");
            }
        }
    }
}
