using System;

namespace Program04_MultipleCatch
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.Write("Enter first number: ");
                string input1 = Console.ReadLine() ?? "";
                int a = int.Parse(input1);

                Console.Write("Enter second number: ");
                string input2 = Console.ReadLine() ?? "";
                int b = int.Parse(input2);

                int result = a / b;
                Console.WriteLine($"Result: {result}");
            }
            catch (FormatException ex)
            {
                Console.WriteLine($"FormatException: {ex.Message}");
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine($"DivideByZeroException: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception: {ex.Message}");
            }
        }
    }
}
