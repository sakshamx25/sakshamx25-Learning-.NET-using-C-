using System;

namespace Program07_InvalidLoginException
{
    public class InvalidLoginException : Exception
    {
        public InvalidLoginException(string message) : base(message) { }
    }

    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.Write("Enter username: ");
                string username = Console.ReadLine() ?? "";

                Console.Write("Enter password: ");
                string password = Console.ReadLine() ?? "";

                if (username != "admin" || password != "1234")
                {
                    throw new InvalidLoginException("Incorrect username or password.");
                }

                Console.WriteLine("Login successful.");
            }
            catch (InvalidLoginException ex)
            {
                Console.WriteLine($"InvalidLoginException caught: {ex.Message}");
            }
        }
    }
}
