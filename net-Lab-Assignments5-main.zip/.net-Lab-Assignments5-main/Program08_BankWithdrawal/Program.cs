using System;

namespace Program08_BankWithdrawal
{
    public class InsufficientBalanceException : Exception
    {
        public InsufficientBalanceException(string message) : base(message) { }
    }

    public class BankAccount
    {
        public decimal Balance { get; private set; }

        public BankAccount(decimal balance)
        {
            Balance = balance;
        }

        public void Withdraw(decimal amount)
        {
            if (amount > Balance)
            {
                throw new InsufficientBalanceException("Withdrawal amount exceeds balance.");
            }
            Balance -= amount;
            Console.WriteLine($"Withdrawal successful. Balance: {Balance}");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            BankAccount account = new BankAccount(1000);

            try
            {
                Console.Write("Enter withdrawal amount: ");
                decimal amount = decimal.Parse(Console.ReadLine() ?? "0");
                account.Withdraw(amount);
            }
            catch (InsufficientBalanceException ex)
            {
                Console.WriteLine($"InsufficientBalanceException caught: {ex.Message}");
            }
            catch (FormatException ex)
            {
                Console.WriteLine($"FormatException caught: {ex.Message}");
            }
            finally
            {
                Console.WriteLine($"Final balance: {account.Balance}");
            }
        }
    }
}
