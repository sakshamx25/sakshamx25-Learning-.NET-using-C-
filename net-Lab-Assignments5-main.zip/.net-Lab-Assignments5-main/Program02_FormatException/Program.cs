using System;

namespace Program02_FormatException
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.Write("Enter an integer: ");
                string input = Console.ReadLine() ?? "";
                int number = int.Parse(input);
                Console.WriteLine($"Entered integer: {number}");
            }
            catch (FormatException ex)
            {
                Console.WriteLine($"FormatException caught: {ex.Message}");
            }
        }
    }
}
