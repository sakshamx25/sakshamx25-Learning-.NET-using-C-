using System;

namespace Program01_DivideByZero
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.Write("Enter first number: ");
                int num1 = Convert.ToInt32(Console.ReadLine() ?? "0");

                Console.Write("Enter second number: ");
                int num2 = Convert.ToInt32(Console.ReadLine() ?? "0");

                int result = num1 / num2;
                Console.WriteLine($"Result: {result}");
            }
            catch (DivideByZeroException ex)
            {
                Console.WriteLine($"DivideByZeroException caught: {ex.Message}");
            }
            catch (FormatException ex)
            {
                Console.WriteLine($"FormatException caught: {ex.Message}");
            }
        }
    }
}
