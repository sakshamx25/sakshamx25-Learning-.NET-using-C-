using System;

namespace Program03_IndexOutOfRange
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = { 10, 20, 30, 40, 50 };

            try
            {
                Console.Write("Enter array index: ");
                string input = Console.ReadLine() ?? "";
                int index = int.Parse(input);
                Console.WriteLine($"Element at index {index}: {numbers[index]}");
            }
            catch (IndexOutOfRangeException ex)
            {
                Console.WriteLine($"IndexOutOfRangeException caught: {ex.Message}");
            }
            catch (FormatException ex)
            {
                Console.WriteLine($"FormatException caught: {ex.Message}");
            }
        }
    }
}
