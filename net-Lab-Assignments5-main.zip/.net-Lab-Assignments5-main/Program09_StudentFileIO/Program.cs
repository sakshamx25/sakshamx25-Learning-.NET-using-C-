using System;
using System.IO;

namespace Program09_StudentFileIO
{
    class Program
    {
        static void Main(string[] args)
        {
            string filePath = "student.txt";

            try
            {
                Console.Write("Enter Student Name: ");
                string name = Console.ReadLine() ?? "";

                Console.Write("Enter Student Roll No: ");
                string rollNo = Console.ReadLine() ?? "";

                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    writer.WriteLine($"Roll No: {rollNo}");
                    writer.WriteLine($"Name: {name}");
                }

                Console.WriteLine("\nFile contents:");
                using (StreamReader reader = new StreamReader(filePath))
                {
                    string? line;
                    while ((line = reader.ReadLine()) != null)
                    {
                        Console.WriteLine(line);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Exception caught: {ex.Message}");
            }
        }
    }
}
