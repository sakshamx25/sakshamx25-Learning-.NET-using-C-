using System;

namespace Program06_StudentMarks
{
    class Program
    {
        static void Main(string[] args)
        {
            double[] marks = new double[5];

            for (int i = 0; i < 5; i++)
            {
                try
                {
                    Console.Write($"Enter marks for subject {i + 1}: ");
                    double mark = double.Parse(Console.ReadLine() ?? "");

                    if (mark < 0 || mark > 100)
                    {
                        throw new ArgumentOutOfRangeException(nameof(mark), "Marks must be between 0 and 100.");
                    }

                    marks[i] = mark;
                }
                catch (FormatException ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                    return;
                }
                catch (ArgumentOutOfRangeException ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                    return;
                }
            }

            double total = 0;
            foreach (double m in marks)
            {
                total += m;
            }
            Console.WriteLine($"Total: {total}, Average: {total / 5.0}");
        }
    }
}
