using System;

namespace Program05_ATMSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.Write("Enter balance: ");
                decimal balance = decimal.Parse(Console.ReadLine() ?? "0");

                Console.Write("Enter withdrawal amount: ");
                decimal withdraw = decimal.Parse(Console.ReadLine() ?? "0");

                if (withdraw > balance)
                {
                    throw new InvalidOperationException("Insufficient balance.");
                }

                balance -= withdraw;
                Console.WriteLine($"Remaining balance: {balance}");
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
            catch (FormatException ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
            finally
            {
                Console.WriteLine("Transaction process completed.");
            }
        }
    }
}
